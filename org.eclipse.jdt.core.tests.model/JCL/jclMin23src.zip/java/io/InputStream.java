package java.io;

public class InputStream implements AutoCloseable {
	public void close() {}
}
