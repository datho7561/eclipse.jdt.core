package java.lang;
public final class Long extends Number{
}
