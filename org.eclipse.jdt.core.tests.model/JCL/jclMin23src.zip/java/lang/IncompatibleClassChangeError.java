
package java.lang;
public
class IncompatibleClassChangeError extends LinkageError {

	static final long serialVersionUID = 1L;

    public IncompatibleClassChangeError () {
        super();
    }

    public IncompatibleClassChangeError(String s) {
        super(s);
    }
}
