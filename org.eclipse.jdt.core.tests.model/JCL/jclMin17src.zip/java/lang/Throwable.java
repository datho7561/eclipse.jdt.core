package java.lang;

public class Throwable {

	public Throwable(java.lang.String message) {
		// TODO Auto-generated constructor stub
	}

	public Throwable() {
		// TODO Auto-generated constructor stub
	}

	public Throwable(java.lang.String message, Throwable cause) {
		// TODO Auto-generated constructor stub
	}

	public Throwable(Throwable cause) {
		// TODO Auto-generated constructor stub
	}
}
