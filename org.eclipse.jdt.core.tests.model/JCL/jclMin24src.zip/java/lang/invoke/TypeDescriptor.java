package java.lang.invoke;

import java.util.List;

public interface TypeDescriptor {
    String descriptorString();
}
