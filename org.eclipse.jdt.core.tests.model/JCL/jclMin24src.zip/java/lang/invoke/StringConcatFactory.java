package java.lang.invoke;

public final class StringConcatFactory {
}
