package java.lang;

public class RuntimeException extends Exception {

	public RuntimeException(java.lang.String s) {
		// TODO Auto-generated constructor stub
	}

	public RuntimeException() {
		// TODO Auto-generated constructor stub
	}
}
