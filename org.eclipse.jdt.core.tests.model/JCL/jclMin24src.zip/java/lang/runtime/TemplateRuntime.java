package java.lang.runtime;

public final class TemplateRuntime {
}

