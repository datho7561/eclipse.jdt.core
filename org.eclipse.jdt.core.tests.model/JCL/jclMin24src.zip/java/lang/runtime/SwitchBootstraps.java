package java.lang.runtime;

public class SwitchBootstraps {
}

