package java.lang;
public final class Float extends Number{
}

